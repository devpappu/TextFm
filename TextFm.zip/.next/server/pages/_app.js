/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_pages_home_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/pages/home.css */ \"./styles/pages/home.css\");\n/* harmony import */ var _styles_pages_home_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_pages_home_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _styles_tailwind_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/tailwind.css */ \"./styles/tailwind.css\");\n/* harmony import */ var _styles_tailwind_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_tailwind_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../redux/store */ \"./redux/store.js\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next-redux-wrapper */ \"next-redux-wrapper\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_6__);\n\n\n// import \"react-loader-spinner/dist/loader/css/react-spinner-loader.css\";\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Global IT\\\\Desktop\\\\TextFm\\\\pages\\\\_app.js\",\n            lineNumber: 14,\n            columnNumber: 9\n        }, this)\n    }, void 0, false);\n}\n// export default MyApp\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_redux_store__WEBPACK_IMPORTED_MODULE_5__.wrapper.withRedux(MyApp));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBMEI7QUFDMUIsMEVBQTBFO0FBQzNDO0FBQ0c7QUFDRjtBQUVTO0FBQ0M7QUFFMUMsU0FBU0csS0FBSyxDQUFDLEVBQUVDLFNBQVMsR0FBRUMsU0FBUyxHQUFFLEVBQUU7SUFFdkMscUJBQ0U7a0JBQ0ksNEVBQUNELFNBQVM7WUFBRSxHQUFHQyxTQUFTOzs7OztnQkFBSTtxQkFFN0IsQ0FDSjtDQUNGO0FBRUQsdUJBQXVCO0FBQ3ZCLGlFQUFlSiwyREFBaUIsQ0FBQ0UsS0FBSyxDQUFDLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tZy10YWxlbnQtbWFya2V0Ly4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbi8vIGltcG9ydCBcInJlYWN0LWxvYWRlci1zcGlubmVyL2Rpc3QvbG9hZGVyL2Nzcy9yZWFjdC1zcGlubmVyLWxvYWRlci5jc3NcIjtcclxuaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xyXG5pbXBvcnQgJy4uL3N0eWxlcy9wYWdlcy9ob21lLmNzcyc7XHJcbmltcG9ydCAnLi4vc3R5bGVzL3RhaWx3aW5kLmNzcyc7XHJcblxyXG5pbXBvcnQgeyB3cmFwcGVyIH0gZnJvbSAnLi4vcmVkdXgvc3RvcmUnO1xyXG5pbXBvcnQgd2l0aFJlZHV4IGZyb20gJ25leHQtcmVkdXgtd3JhcHBlcidcclxuXHJcbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcblxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcblxyXG4vLyBleHBvcnQgZGVmYXVsdCBNeUFwcFxyXG5leHBvcnQgZGVmYXVsdCB3cmFwcGVyLndpdGhSZWR1eChNeUFwcCk7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIndyYXBwZXIiLCJ3aXRoUmVkdXgiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./redux/reducer/SubscribeFormrReducer.js":
/*!************************************************!*\
  !*** ./redux/reducer/SubscribeFormrReducer.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst initialData = false;\nconst SubscribeFormReducer = (state = initialData, action)=>{\n    switch(action.type){\n        case \"SWITCH_SUBSCRIBE_FORM\":\n            return state = !state;\n        default:\n            return state;\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubscribeFormReducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9yZWR1Y2VyL1N1YnNjcmliZUZvcm1yUmVkdWNlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsTUFBTUEsV0FBVyxHQUFJLEtBQUs7QUFFMUIsTUFBTUMsb0JBQW9CLEdBQUUsQ0FBQ0MsS0FBSyxHQUFHRixXQUFXLEVBQUVHLE1BQU0sR0FBSTtJQUV2RCxPQUFPQSxNQUFNLENBQUNDLElBQUk7UUFFZixLQUFLLHVCQUF1QjtZQUFHLE9BQU9GLEtBQUssR0FBSSxDQUFDQSxLQUFLLENBQUM7UUFDdEQ7WUFBVSxPQUFPQSxLQUFLLENBQUM7S0FDekI7Q0FFTDtBQUVELGlFQUFlRCxvQkFBb0IsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL21nLXRhbGVudC1tYXJrZXQvLi9yZWR1eC9yZWR1Y2VyL1N1YnNjcmliZUZvcm1yUmVkdWNlci5qcz9jODA3Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGluaXRpYWxEYXRhID0gIGZhbHNlO1xyXG5cclxuY29uc3QgU3Vic2NyaWJlRm9ybVJlZHVjZXIgPShzdGF0ZSA9IGluaXRpYWxEYXRhLCBhY3Rpb24pID0+e1xyXG5cclxuICAgICBzd2l0Y2goYWN0aW9uLnR5cGUpe1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNhc2UgXCJTV0lUQ0hfU1VCU0NSSUJFX0ZPUk1cIiA6IHJldHVybiBzdGF0ZSA9ICAhc3RhdGU7XHJcbiAgICAgICAgZGVmYXVsdCA6IHJldHVybiBzdGF0ZTtcclxuICAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdWJzY3JpYmVGb3JtUmVkdWNlcjsiXSwibmFtZXMiOlsiaW5pdGlhbERhdGEiLCJTdWJzY3JpYmVGb3JtUmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwidHlwZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./redux/reducer/SubscribeFormrReducer.js\n");

/***/ }),

/***/ "./redux/reducer/rootReducer.js":
/*!**************************************!*\
  !*** ./redux/reducer/rootReducer.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _SubscribeFormrReducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubscribeFormrReducer */ \"./redux/reducer/SubscribeFormrReducer.js\");\n/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ \"redux\");\n/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst rootReducer = (0,redux__WEBPACK_IMPORTED_MODULE_1__.combineReducers)({\n    SubscribeFormReducer: _SubscribeFormrReducer__WEBPACK_IMPORTED_MODULE_0__[\"default\"]\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rootReducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9yZWR1Y2VyL3Jvb3RSZWR1Y2VyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDMkQ7QUFFckI7QUFFdEMsTUFBTUUsV0FBVyxHQUFHRCxzREFBZSxDQUFDO0lBQ2hDRCxvQkFBb0I7Q0FDdkIsQ0FBQztBQUdGLGlFQUFlRSxXQUFXLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tZy10YWxlbnQtbWFya2V0Ly4vcmVkdXgvcmVkdWNlci9yb290UmVkdWNlci5qcz8zZjVmIl0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgU3Vic2NyaWJlRm9ybVJlZHVjZXIgZnJvbSBcIi4vU3Vic2NyaWJlRm9ybXJSZWR1Y2VyXCI7XHJcblxyXG5pbXBvcnQge2NvbWJpbmVSZWR1Y2Vyc30gZnJvbSBcInJlZHV4XCI7XHJcblxyXG5jb25zdCByb290UmVkdWNlciA9IGNvbWJpbmVSZWR1Y2Vycyh7XHJcbiAgICBTdWJzY3JpYmVGb3JtUmVkdWNlclxyXG59KVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJvb3RSZWR1Y2VyOyJdLCJuYW1lcyI6WyJTdWJzY3JpYmVGb3JtUmVkdWNlciIsImNvbWJpbmVSZWR1Y2VycyIsInJvb3RSZWR1Y2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./redux/reducer/rootReducer.js\n");

/***/ }),

/***/ "./redux/store.js":
/*!************************!*\
  !*** ./redux/store.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"wrapper\": () => (/* binding */ wrapper)\n/* harmony export */ });\n/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ \"redux\");\n/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-redux-wrapper */ \"next-redux-wrapper\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-devtools-extension */ \"redux-devtools-extension\");\n/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _reducer_rootReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reducer/rootReducer */ \"./redux/reducer/rootReducer.js\");\n\n\n\n// import thunkMiddleware from 'redux-thunk';\n\n// const bindMiddleware = middleware => {\n//     return composeWithDevTools(applyMiddleware(...middleware));\n// };\nconst initStore = (initialState = {})=>{\n    return (0,redux__WEBPACK_IMPORTED_MODULE_0__.createStore)(_reducer_rootReducer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], initialState);\n};\n// const initStore = (initialState = {}) => {\n//     return createStore(rootReducer, initialState, bindMiddleware([thunkMiddleware]));\n// };\nconst wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(initStore, {\n    debug: true\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9zdG9yZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFxRDtBQUNGO0FBQ1k7QUFFL0QsNkNBQTZDO0FBQ0c7QUFFaEQseUNBQXlDO0FBQ3pDLGtFQUFrRTtBQUNsRSxLQUFLO0FBRUwsTUFBTUssU0FBUyxHQUFHLENBQUNDLFlBQVksR0FBRyxFQUFFLEdBQUs7SUFDckMsT0FBT04sa0RBQVcsQ0FBQ0ksNERBQVcsRUFBRUUsWUFBWSxDQUFDLENBQUM7Q0FDakQ7QUFDRCw2Q0FBNkM7QUFDN0Msd0ZBQXdGO0FBQ3hGLEtBQUs7QUFFRSxNQUFNQyxPQUFPLEdBQUdMLGlFQUFhLENBQUNHLFNBQVMsRUFBRTtJQUFFRyxLQUFLLEVBQUUsSUFBSTtDQUFFLENBQUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL21nLXRhbGVudC1tYXJrZXQvLi9yZWR1eC9zdG9yZS5qcz8zNTQ5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVN0b3JlLCBhcHBseU1pZGRsZXdhcmUgfSBmcm9tICdyZWR1eCc7XHJcbmltcG9ydCB7IGNyZWF0ZVdyYXBwZXIgfSBmcm9tICduZXh0LXJlZHV4LXdyYXBwZXInO1xyXG5pbXBvcnQgeyBjb21wb3NlV2l0aERldlRvb2xzIH0gZnJvbSAncmVkdXgtZGV2dG9vbHMtZXh0ZW5zaW9uJztcclxuXHJcbi8vIGltcG9ydCB0aHVua01pZGRsZXdhcmUgZnJvbSAncmVkdXgtdGh1bmsnO1xyXG5pbXBvcnQgcm9vdFJlZHVjZXIgZnJvbSAnLi9yZWR1Y2VyL3Jvb3RSZWR1Y2VyJztcclxuXHJcbi8vIGNvbnN0IGJpbmRNaWRkbGV3YXJlID0gbWlkZGxld2FyZSA9PiB7XHJcbi8vICAgICByZXR1cm4gY29tcG9zZVdpdGhEZXZUb29scyhhcHBseU1pZGRsZXdhcmUoLi4ubWlkZGxld2FyZSkpO1xyXG4vLyB9O1xyXG5cclxuY29uc3QgaW5pdFN0b3JlID0gKGluaXRpYWxTdGF0ZSA9IHt9KSA9PiB7XHJcbiAgICByZXR1cm4gY3JlYXRlU3RvcmUocm9vdFJlZHVjZXIsIGluaXRpYWxTdGF0ZSk7XHJcbn07XHJcbi8vIGNvbnN0IGluaXRTdG9yZSA9IChpbml0aWFsU3RhdGUgPSB7fSkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGNyZWF0ZVN0b3JlKHJvb3RSZWR1Y2VyLCBpbml0aWFsU3RhdGUsIGJpbmRNaWRkbGV3YXJlKFt0aHVua01pZGRsZXdhcmVdKSk7XHJcbi8vIH07XHJcblxyXG5leHBvcnQgY29uc3Qgd3JhcHBlciA9IGNyZWF0ZVdyYXBwZXIoaW5pdFN0b3JlLCB7IGRlYnVnOiB0cnVlIH0pOyJdLCJuYW1lcyI6WyJjcmVhdGVTdG9yZSIsImFwcGx5TWlkZGxld2FyZSIsImNyZWF0ZVdyYXBwZXIiLCJjb21wb3NlV2l0aERldlRvb2xzIiwicm9vdFJlZHVjZXIiLCJpbml0U3RvcmUiLCJpbml0aWFsU3RhdGUiLCJ3cmFwcGVyIiwiZGVidWciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./redux/store.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "./styles/pages/home.css":
/*!*******************************!*\
  !*** ./styles/pages/home.css ***!
  \*******************************/
/***/ (() => {



/***/ }),

/***/ "./styles/tailwind.css":
/*!*****************************!*\
  !*** ./styles/tailwind.css ***!
  \*****************************/
/***/ (() => {



/***/ }),

/***/ "next-redux-wrapper":
/*!*************************************!*\
  !*** external "next-redux-wrapper" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux");

/***/ }),

/***/ "redux-devtools-extension":
/*!*******************************************!*\
  !*** external "redux-devtools-extension" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-devtools-extension");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();