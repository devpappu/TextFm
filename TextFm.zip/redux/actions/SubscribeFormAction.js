export const SET_SUBSCRIBE_FORM = () =>{
    return{
        type: "SWITCH_SUBSCRIBE_FORM"
    }
}