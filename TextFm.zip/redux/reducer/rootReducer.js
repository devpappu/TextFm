
import SubscribeFormReducer from "./SubscribeFormrReducer";

import {combineReducers} from "redux";

const rootReducer = combineReducers({
    SubscribeFormReducer
})


export default rootReducer;