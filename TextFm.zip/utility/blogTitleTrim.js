export default function blogTitleTrim(value) {
    return value.substring(0, 375) + '...'
  }