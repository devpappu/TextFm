
 export default function formatCurrency(value) {
    return '₱ ' + parseFloat(value).toFixed(2);
  }