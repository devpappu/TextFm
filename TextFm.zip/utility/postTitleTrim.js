export default function postTitleTrim(value) {
    return value.substring(0, 30) + '...'
  }